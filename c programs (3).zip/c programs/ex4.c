void digitOrFloat(char *ptr);
int c=0,flag=0;
void check(char *p)
   {   
       if(p[0]=='-' || isdigit(p[0])!=0)
       {   
        digitOrFloat(p);
       }
       else if(p[0]=='.')
       {    c=c+1;
           digitOrFloat(p);
       }
       else 
       {
        for(int i =0;i<strlen(p);i++) 
        {
            if(isalpha(p[i])!=0 || p[i]=='_')
            {
                continue;
            }
            else
            {
                flag=1;
                break;
            }
        }
        if(flag==0)
        {
            printf("Argument is a string ");
        }
        else
        printf("Argument is invalid type");
       }
   }
void digitOrFloat(char *ptr)
{   
    for(int i =1;i<strlen(ptr);i++) 
          {
              if(ptr[i]=='.')
              {
                  c=c+1;
              }
              else
              {
                  if(isdigit(ptr[i])!=0)
                  {
                      continue;
                  }
                  else
                  {
                      flag=1;
                      break;
                  }
              }
          }
          if(flag==0){
          if(c==0)
          {
              printf("Argument is an integer");
          }
          else if(c>1)
          {
               printf("Argument is invalid type ");
          }
          else
               printf("Argument is a floating point number ");
          }
          else
             printf("Argument is invalid type ");
}
int main(int argc, char *argv[])
{
    char *c=argv[1];
    check(c);
    return 0;
}