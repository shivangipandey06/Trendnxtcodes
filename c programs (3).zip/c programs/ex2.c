#include <stdio.h>

void main()
{
    int c=0;
    int a[100];
    int n,b=0,k=0;
    printf("Enter the size of array");
    scanf("%d",&n);
    int i ,len=0;
    for(i=0;i<n;i++)
    {
       printf("Enter the %d element of array ",i+1);
       scanf("%d",&a[i]);
    }
    printf("Non Repeating digits are");
    for (int i=0;i<n;i++)
    {   c=0;
        int z=a[i];
        if(z!=0){
        for(int j=i+1;j<n;j++)
        {   
            if(a[j]==z)
            {   
                len=n-1;
                c=c+1;
                a[j]=0;
            }
        }
        if(c==0)
        {
            b=z;
            printf(" %d ",b);
        }
        }
       
    }
    printf("\n""Unique Elements ");
    for(int i=0;i<len;i++)
    {
        if(a[i]!=0)
        printf(" %d ",a[i]);
        else
        continue;
    }
     
    
    
 }