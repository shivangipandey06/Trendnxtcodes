#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
long toBin(unsigned int);
int toDecimal(int *n ,int l);
void minmax(unsigned int  val,unsigned int  *pmin, unsigned int  *pmax)
{
    long bno=toBin(val);
    int c = 0,minc=0,maxc=0; /* digit position */
    long n = bno;
    while (n != 0)
     {
         n/= 10;
         c++;
     }
    int numberArray[c],min[c], max[c];
    
    c = 0;    
    n = bno;
    while (n != 0)
    {
        numberArray[c] = n % 10;
        n /= 10;
        c++;
    }
    for(int i=0;i<c;i++)
    {
        if(numberArray[i]==1)
        {
            min[minc++] =numberArray[i];
        }
    }
    for(int j=0;j<minc;j++)
        {
            max[maxc++] =min[j];
        } 
    for(int i=0;i<(c-minc);i++){
        
        max[maxc++]=0;
    }
    int minResult=toDecimal(min,minc);
    int maxResult=toDecimal(max,maxc);
    printf("Input value   :%ld \n",bno);
    printf("Smalest value :%d \n",minResult);
    printf("Largest value :%d \n",maxResult);
    
}
int main(int argc, char *argv[])
{   
    unsigned int a= atoi(argv[1]);
    minmax(a,0,0);
}

long toBin(unsigned int dno)
{
    long  bno=0,r,f=1;
    while(dno != 0)
    {
         r = dno % 2;
         bno = bno + r * f;
         f = f * 10;
         dno = dno / 2;
    }
    return bno;
}
int toDecimal(int *n ,int len)
{   int p=0,dec=0;
    for(int i=len-1;i>=0;i--)
    {
     dec=dec+n[i]*pow(2,p++);
    }
    return dec;
}