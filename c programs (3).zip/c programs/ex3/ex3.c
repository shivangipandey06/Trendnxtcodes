#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int isOctal(char *line)
{
    for (int i = 1; i < strlen(line); i++)
    {
        if (((int)line[i] - '0') <8 && ((int)line[i] - '0') >= 0)
            continue;
        return 0;
    }
    return 1;
}

int isDecimal(char *line)
{
    for (int i = 1; i < strlen(line); i++)
    {
        if (((int)line[i] - '0') <10 && ((int)line[i] - '0') >= 0)
            continue;
        return 0;
    }
    return 1;
}

int isBin(char *line)
{
    for (int i = 1; i < strlen(line); i++)
    {
        if (((int)line[i] - '0') < 2 && ((int)line[i] - '0') >= 0)
            continue;
        return 0;
    }
    return 1;
}

int isHex(char *line)
{
    for (int i = 2; i < strlen(line); i++)
    {
        if (isxdigit(line[i]))
            continue;
        return 0;
    }
    return 1;
}

int main(void)
{
    int counter = 1;
    static const char filename[] = "test.txt";
    FILE *file = fopen(filename, "r");
    if (file != NULL)
    {
        char line[128];                                /* or other suitable maximum line size */
        while (fgets(line, sizeof line, file) != NULL) /* read a line */
        {
            line[strlen(line) - 1] = 0;
            if (line[0] == '0')
            {
                if (line[1] == 'x')
                {
                    // hexadecimal
                    if (isHex(line))
                    {
                        // printf("hex number \n");
                    }
                    else
                    {
                        printf("%d: %s - invalid hexa number\n", counter, line);
                    }
                }
                else
                {
                    //octal number
                    if (isOctal(line) == 1)
                    {
                        // printf("octal  number \n");
                    }
                    else
                    {
                        printf("%d: %s - invalid octal number\n", counter, line);
                    }
                }
            }
            else if (line[0] == 'b')
            {

                if (isBin(line) == 1)
                {
                    // printf("binary  number \n");
                }
                else
                {
                    printf("%d: %s - invalid binary number\n", counter, line);
                }
            }
            else if (((int)line[0] - '0') <= 10)
            {
                if (isDecimal(line) == 1)
                {
                    // printf("decimal  number \n");
                }
                else
                {
                    printf("%d: %s - invalid decimal number\n", counter, line);
                }
            }
            else
            {
                printf("%d: %s - invalid prefix\n", counter, line);
            }
            counter++;
        }
        fclose(file);
    }
    else
    {
        perror(filename); /* why didn't the file open? */
    }
    return 0;
}