
#include <stdio.h> 
void identify(int *p, int n) 
{ 
    int i, j,flag=0;; 
    for (i = 0; i < n; i++)
    {
      for (j = 0; j < n; j++) 
      {
        if(i==j)
        {
            if(*((p+i*n) + j)==1)
            {
            continue;
            }
            else
            flag=1;
            break;
        }
        else
        {
            if(*((p+i*n) + j)==0)
            {
                continue;
            }
            else
            {
                flag=1;
                break;
            }
        }
        
      }
    }
    if(flag==0)
    {
        printf(" Identity Matrix");
    }
    else
    {
        printf("Not an Identity Matrix");
    }
} 
  
int main() 
{   int m,n;
    printf("Enter the num of row of array");
    scanf("%d",&m);
    printf("Enter the num of coulmn of array");
    scanf("%d",&n);
    printf("Enter values of an array");
    int arr[m][n]; 
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
           scanf("%d",&arr[i][j]); 
        }
    }
    if(m==n && m>1 && n>1)
    {
    // We can also use "print(&arr[0][0], m, n);" 
    identify((int *)arr, m); 
    return 0; 
    }
    else
    {
        printf("Invalid");
    }
} 