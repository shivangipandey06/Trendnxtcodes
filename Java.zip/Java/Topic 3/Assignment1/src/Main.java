
public class Main {
	
	public static void main(String[] args) {
		try
		{
			String name=args[0];
			int age=Integer.parseInt(args[1]);
			if(age<18)
			{
				throw new AgeException("Age is less than 18");
			}
			else if(age>60)
			{
				throw new AgeException("Age is greater than 60");
			}
			System.out.println("The age of "+name+" is "+age);
		}
		catch(AgeException e)
		{
			System.out.println(e);
		}
	}

	
	}
