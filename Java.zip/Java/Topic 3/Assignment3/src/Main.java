
public class Main {
	
	public static void main(String[] args) {
		try
		{
			double average=0;
			int number[]=new int[5];
			for(int i=0;i<5;i++)
			{
				number[i]=Integer.parseInt(args[i]);
				average+=number[i];
			}
			average/=5;
			System.out.println("The average is "+average);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("The arguments given is less than 5");
		}
	}

	
	}
