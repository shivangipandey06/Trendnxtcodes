import java.util.Scanner;
public class Main {
	
	public static void main(String[] args) {
		String s;
		System.out.println("Enter the string");
		Scanner sc=new Scanner(System.in);
		s=sc.next();
		Boolean isPalindrome=isPalindrome(s,0,s.length()-1);
		if(isPalindrome)
			System.out.println("It is a Palindrome");
		else
			System.out.println("It is not a Palindrome");
		sc.close();

	}

	private static Boolean isPalindrome(String str, int start,int end) {
		if(start>end)
			return true;
		if(str.charAt(start)==str.charAt(end))
			return true&isPalindrome(str,start+1,end-1);
		else
			return false;
	}

	}
