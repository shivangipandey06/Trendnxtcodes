import java.util.Scanner;
public class Main {
	
	public static void main(String[] args) {
		String str;
		String ch;
		System.out.println("Enter the string");
		Scanner sc=new Scanner(System.in);
		str=sc.next();
		System.out.println("Enter the character to be searched");
		ch=sc.next();
		 int count = str.length() - str.replace(ch, "").length();
	        System.out.println("Number of occurances of 'a' in "+str+" = "+count);
	}

	}