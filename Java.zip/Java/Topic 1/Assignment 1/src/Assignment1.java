public class Assignment1{

     public static void main(String []args){
        System.out.println("Welcome to Java Programming");
        System.out.println("Shivangi");
        
     }
}