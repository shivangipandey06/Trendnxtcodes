import java.util.Scanner;
public class Assignment7{

      public static void main(String[] args) {

            Scanner in = new Scanner(System.in);
            
            System.out.print("Enter number to get factorial:");
            int n=in.nextInt();
            int fact= getFactorial(n);
            System.out.print("Factorial of number is:"+fact);
      }
      
 static int getFactorial(int num) {  
           if (num <= 1)  

              return 1;  

           else 
             return (num * getFactorial(num - 1));  

    }  
}