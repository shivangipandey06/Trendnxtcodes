import java.util.Scanner;
public class Assignment6 {

      public static void main(String[] args) {

            Scanner in = new Scanner(System.in);
            
            System.out.print("Enter size of array:");
            int n=in.nextInt();
            int a[]=new int[n];
            System.out.print("Enter elements of array:");
            for(int i=0;i<n;i++)
            {
               a[i]=in.nextInt(); 
            }
            int max=0;
            for(int i=0;i<n;i++){
                if(a[i]>max)
                {
                    max=a[i];
                }
            }

            System.out.print("Greatest element of array is:"+max); 
      }
}