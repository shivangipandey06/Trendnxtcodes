package Automobile.TwoWheeler;

import Automobile.Vehicle;

public class Honda extends Vehicle{
	int speed=70;
	String modelName="Activa";
	String registrationNumber="9876";
	String ownerName="Shashi";
		@Override
		public String modelName() {
			// TODO Auto-generated method stub
			return modelName;
		}

		@Override
		public String registrationNumber() {
			// TODO Auto-generated method stub
			return registrationNumber;
		}

		@Override
		public String ownerName() {
			// TODO Auto-generated method stub
			return ownerName;
		}
		public int speed() {
			return speed;
		}
		public void cdplayer(){
		System.out.println("provides facility to control the cd player device which is available in the car"); 
		}
}
