package Automobile.TwoWheeler;

import Automobile.Vehicle;

public class Hero extends Vehicle{
	int speed=100;
	String modelName="M1";
	String registrationNumber="12345";
	String ownerName="Sam";
		@Override
		public String modelName() {
			// TODO Auto-generated method stub
			return modelName;
		}

		@Override
		public String registrationNumber() {
			// TODO Auto-generated method stub
			return registrationNumber;
		}

		@Override
		public String ownerName() {
			// TODO Auto-generated method stub
			return ownerName;
		}
		public void radio() {
			System.out.println("Provides facility to control the radio device");
		}
		public int speed() {
			return speed;
		}


}
