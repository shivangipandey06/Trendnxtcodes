import Automobile.TwoWheeler.Hero;
import Automobile.TwoWheeler.Honda;

public class Main {

	public static void main(String[] args) {
		Hero hero=new Hero();
		Honda honda=new Honda();
		System.out.print(hero.modelName()+" "+hero.ownerName()+" "+hero.registrationNumber()+" "+hero.speed()+" ");
		hero.radio();
		System.out.println(honda.modelName()+" "+honda.ownerName()+" "+honda.registrationNumber()+" "+honda.speed());
		honda.cdplayer();
	}

}