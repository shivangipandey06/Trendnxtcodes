package Test;

public class Foundation {
 
	private int var1; 
	int  var2;  //default
	protected int var3;  
	public int var4; 
}
