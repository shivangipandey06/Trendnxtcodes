package Check;

import Test.Foundation;

public class Main {
	
	public static void main(String args[])
	{
		Foundation f =new Foundation();
		
		// Only public is accessible 
				System.out.println(f.var4);
	}

}
