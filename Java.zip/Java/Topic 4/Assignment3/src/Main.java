
public class Main {
public static void main(String args[])
{
	EmployeeDB empDb=new EmployeeDB();
	Employee e1=new Employee();
	e1.setEmpId(1);
	e1.setEmpName("Sam");
	e1.setEmpRole("Web developer");
	e1.setSalary(125000);
	empDb.addEmployee(e1);
	Employee e2=new Employee();
	e2.setEmpId(2);
	e2.setEmpName("Neerja");
	e2.setEmpRole("UI developer");
	e2.setSalary(360700);
	empDb.addEmployee(e2);
	Employee e3=new Employee();
	e3.setEmpId(3);
	e3.setEmpName("Astha");
	e3.setEmpRole("Frontend developer");
	e3.setSalary(627280);
	empDb.addEmployee(e3);
	System.out.println("Add Method");
	Employee[] employeList=empDb.listAll();
	for(Employee employe:employeList)
	{
		System.out.println(employe.getEmpName()+":"+employe.getEmpRole());
	}
	System.out.println("--------------------------------------------");
	System.out.println("Delete Method");
	empDb.deleteEmployee(1);
	Employee[] employeList1=empDb.listAll();
	for(Employee employe:employeList1)
	{
		System.out.println(employe.getEmpName()+":"+employe.getEmpRole());
	}
	System.out.println("--------------------------------------------");
	System.out.println("showPaySlip Method");
	System.out.println(e2.getEmpName()+":"+empDb.showPaySlip(2));
}
}
