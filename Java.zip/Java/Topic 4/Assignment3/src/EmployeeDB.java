
import java.util.ArrayList;

public class EmployeeDB {
ArrayList<Employee> al=new ArrayList<Employee>();
boolean addEmployee(Employee e)
{
	try {
		return this.al.add(e);
	}
	catch(Exception exception)
	{
		System.out.println(exception);
	return false;
	}
}
boolean deleteEmployee(int empCode)
{
	try {
	for(Employee employee:al)
	{
		if(employee.getEmpId()==empCode)
		{
	al.remove(employee);
	return true;
		}
	}
			return false;
	}
	catch(Exception exception)
	{
		System.out.println(exception);
	return false;
	}
	
}
String showPaySlip(int eCode)
{
	for(Employee employee:al)
		if(employee.getEmpId()==eCode)
	return ""+employee.getSalary();
	return null;
	
}
Employee[] listAll(){
	Employee employee[]=this.al.toArray(new Employee[this.al.size()]);
	return employee;
	
}
}
