
import java.util.HashSet;
import java.util.Iterator;
public class Main {
public static void main(String args[])
{
	HashSet<String> employee=new HashSet<String>();
	employee.add("Shivangi");
	employee.add("Sakshi");
	employee.add("Mansi");
	employee.add("Diksha");
	employee.add("Richa");
	Iterator names=employee.iterator();
	System.out.println("Employee names are ::");
	while(names.hasNext()) {
		System.out.println(names.next());
	}
}
}