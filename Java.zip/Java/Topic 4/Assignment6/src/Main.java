
public class Main {
public static void main(String args[])
{
	//Finalized will be invoked only once
	Test test=new Test();
	test=new Test();
	test=new Test();
	test.finalize();
	}
}

