
public class Test {
	@Override
public void finalize(){
	System.out.println("Finalize method called");
}
}
