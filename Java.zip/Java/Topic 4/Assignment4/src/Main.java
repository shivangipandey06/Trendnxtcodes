
import java.util.HashMap;
import java.util.Scanner;
public class Main {
public static void main(String args[])
{
	HashMap<String,String> hash=new HashMap<String,String>();
	hash.put("Shivangi", "1238887890");
	hash.put("Sakshi", "09876864489");
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the name of person");
	String personName=sc.nextLine();
	System.out.println("The ohone number of : "+name+" is "+hash.get(name));
	sc.close();
}
}
