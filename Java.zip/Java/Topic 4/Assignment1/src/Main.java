
public class Main {
public static void main(String args[])
{
	Factorial fact=new Factorial();
	RandomGenerator r1=new RandomGenerator(fact);
	RandomGenerator r2=new RandomGenerator(fact);
	RandomGenerator r3=new RandomGenerator(fact);
	RandomGenerator r4=new RandomGenerator(fact);
	RandomGenerator r5=new RandomGenerator(fact);
}
}
