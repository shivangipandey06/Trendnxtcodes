
public class Factorial{
int num,fact=1;

	public void display(int num) {
		fact=1;
		if(num==0)
		{
			fact=0;
		}
		else {
		for(int i=1;i<=num;i++)
			fact*=i;
		System.out.println("Number : "+num);
		}
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Factorial of "+num+": "+fact);
	}

}
