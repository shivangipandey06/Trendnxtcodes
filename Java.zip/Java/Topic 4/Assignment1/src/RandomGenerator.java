
import java.util.Random;
public class RandomGenerator extends Thread{
	int randomNum;
	Factorial fact;
	RandomGenerator(Factorial fact)
	{
		Random rand=new Random();
		randomNum=rand.nextInt(10);
		this.fact=fact;
		start();
	}
public void run() {
	synchronized(fact)
	{
	fact.display(randomNum);
	}
}
}
