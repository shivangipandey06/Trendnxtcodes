
public class Main {

	public static void main(String[] args) {
		Instrument[] instrument=new Instrument[10];
		instrument[0]=new Flute();
		instrument[1]=new Guitar();
		instrument[2]=new Piano();
		instrument[0].play();
		instrument[1].play();
		instrument[2].play();
	}

}
