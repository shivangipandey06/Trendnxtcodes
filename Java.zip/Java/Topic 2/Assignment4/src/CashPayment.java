
public class CashPayment extends Payment{
CashPayment()
{

	super.paymentDetails();
}
@Override
void paymentDetails()
{
	System.out.println("The payment method is cash");
}
}
