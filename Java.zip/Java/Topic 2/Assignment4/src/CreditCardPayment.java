
public class CreditCardPayment extends Payment{
String name;
String date;
String number;
CreditCardPayment(String name,String date,String number,double amount)
{
	this.name=name;
	this.number=number;
	this.date=date;
	this.setAmount(amount);
	super.paymentDetails();
}
@Override
void paymentDetails()
{
	System.out.println("The payment method is credit card with card Name Of Card Holder :"+name+", Card Number:"+number+" Card Expiry Date:"+date);
}
}
