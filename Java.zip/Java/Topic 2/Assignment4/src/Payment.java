
public class Payment {
	double amount;

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
	void paymentDetails()
	{
		System.out.println("The amount paid is "+amount);
	}
	
}
