

public class Main {

	public static void main(String[] args) {
		CashPayment cash1=new CashPayment(908.0);
		cash1.paymentDetails();
		CreditCardPayment card1=new CreditCardPayment("Abc", "90098766468489", "10/25", 9903.2);
		card1.paymentDetails();
		CashPayment cash2=new CashPayment(184.99);
		cash2.paymentDetails();
		CreditCardPayment card2=new CreditCardPayment("opk", "40566834254332", "4/29", 5655.5);
		card2.paymentDetails();
	}

}
