package Music;

public interface Playable {
	
	void play();
	

}
