package Music.wind;

import Music.Playable;

public class Saxophone implements Playable {

	@Override
	public void play() {
		System.out.println("Saxophone Playing");
		
	}

}
