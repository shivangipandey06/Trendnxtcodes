package live;

import Music.string.Veena;
import Music.wind.Saxophone;

public class Test {
	
	public static void main(String args[]) {
    Veena veena=new Veena();
    Saxophone saxophone=new Saxophone();
    veena.play();
    saxophone.play();
	}
}
