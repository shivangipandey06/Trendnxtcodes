
public class Magazine extends Book{
String type;
Magazine(int isbn,String title,String type,double price)
{
	this.isbn=isbn;
	this.title=title;
	this.price=price;
	this.type=type;
}
@Override
public String toString()
{
	return "[Isbn: "+isbn+" Title: "+title+" Type:"+type+" Price:"+price+"]";
}
}
