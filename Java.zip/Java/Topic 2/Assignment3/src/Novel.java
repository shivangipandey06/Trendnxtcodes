
public class Novel extends Book{

String author;
Novel(int isbn,String title,String author,double price)
{     this.isbn=isbn;
      this.title=title;
    this.author=author;
	this.author=author;
}
@Override
public String toString()
{
	return "[Isbn: "+isbn+" Title: "+title+" Author:"+author+" Price:"+price+"]";
}
}