public class Book {
	String title;
	int isbn;
	double price;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public static void main(String[] args) {
		Magazine magazine=new Magazine(1, "Comics ", "Childrens ", 99.99);
		Novel novel=new Novel(2, "Arms and the man", "Shakespear", 89.99);
		System.out.println(magazine.toString());
		System.out.println(novel.toString());
	}
	
}