public class Document {
	String text;
	@Override
	public String toString()
	{
		return "1"+text;
	}
	
public void setText(String text) {
		this.text = text;
	}

public static void main(String args[])
{
	}
}
