public class Email extends Document{
String sender;
String recipient;
String title;
String message="";
public String getSender() {
	return sender;
}
public void setSender(String sender) {
	this.sender = sender;
}
public String getRecipient() {
	return recipient;
}
public void setRecipient(String recipient) {
	this.recipient = recipient;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public void setMessage()
{
	this.message+=" "+text;
}
@Override
public String toString()
{
	return "[Sender:"+sender+" Recipient:"+recipient+" Title:"+title+" Message:"+message+"]";
}
public static void main(String args[])
{
	Email email=new Email();
	email.setText("Hello");
	email.setMessage();
	email.setText("This is Shivangi");
	email.setSender("topgear");
	email.setRecipient("Shivangi");
	email.setMessage();
	email.setTitle("Welcome");
	System.out.println(email.toString());
}
}