public class Book{
	
	String isbn;
	String title;
	String author;
	double price;
	
	Book(String isbn, String title, String author, double price){
		this.isbn=isbn;
		this.title=title;
		this.author=author;
		this.price=price;
	}
	
	public void displayDetails() {
		System.out.println("Details of the book are: ");
		System.out.println("ISBN: "+isbn);
		System.out.println("Title: "+title);
		System.out.println("Author: "+author);
		System.out.println("Price: "+price);
	}
	
	public double discountedPrice(double discount) {
		price-=(price * (discount/100));
		return price;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book book=new Book("12345", "Arms and the man", "Shakespear", 500.50);
		book.displayDetails();
		System.out.println("Price of book after Discount: "+book.discountedPrice(25.00));

	}

}